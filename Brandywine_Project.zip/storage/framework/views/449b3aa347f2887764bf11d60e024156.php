<?php
    $menus = \App\Models\Menu::where('published', 1)->get();
?>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($menu->parent_id == 0): ?>
                    <?php
                        $hasSubmenu = $menus->where('parent_id', $menu->id)->count() > 0;
                    ?>
                    <li class="nav-item <?php if($hasSubmenu): ?> dropdown <?php endif; ?>">
                        <a class="nav-link <?php if($hasSubmenu): ?> dropdown-toggle <?php endif; ?>" href="<?php echo e($menu->url ? $menu->url : route('frontend.content-pages.show', $menu->page->id)); ?>" <?php if($hasSubmenu): ?> id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" <?php endif; ?>>
                            <?php echo e($menu->name); ?>

                        </a>
                        <?php if($hasSubmenu): ?>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($submenu->parent_id == $menu->id): ?>
                                    <a class="dropdown-item" href="<?php echo e($submenu->url ? $submenu->url : route('frontend.content-pages.show', $submenu->page->id)); ?>"><?php echo e($submenu->name); ?></a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          
        </ul>
    </div>
<?php /**PATH C:\xampp\htdocs\Brandywine_Project\resources\views/navigation.blade.php ENDPATH**/ ?>