<!---Featured Listings---->
<?php
$page = Request::segment(1);
$category_id = Request::segment(2);
if($page == "home" || $page == ""){
    $inventories = \App\Models\Inventory::with('category')->where('featured', 1)->take(3)->get();
} elseif($page == "categories"){
    $inventories = \App\Models\Inventory::with('category')->where('category_id', $category_id)->paginate(2);
}
elseif($page == "inventories"){
    $inventories = \App\Models\Inventory::with('category')->paginate(12);
}
?>

<?php if($inventories->count() > 0): ?>
<section class="py-3 py-md-5">
  <div class="container">
    <div class="row justify-content-md-center">
      <div class="col-12 col-md-10 col-lg-8 col-xl-7 col-xxl-6">
        <?php if($page == "home" || $page == ""): ?>
        <h2 class="mb-4 display-5 text-center">Featured Inventory</h2>
        <?php elseif($page == "inventories"): ?>
        <h2 class="mb-4 display-5 text-center">Inventory</h2>
        <?php elseif($page == "categories"): ?>
        <?php endif; ?>
        <p class="text-secondary mb-5 text-center lead fs-4">
            Discover our top picks from our extensive inventory. These featured buses are selected for their exceptional quality, reliability, and value.
        </p>
        <hr class="w-50 mx-auto mb-5 mb-xl-9 border-dark-subtle">
      </div>
    </div>
  </div>

  <div class="container overflow-hidden">
    <div class="row gy-4 gy-xxl-5">
        <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-12 col-md-6 col-lg-4 d-flex mb-4">
        <article class="d-flex">
          <div class="card border border-dark" style="--bs-card-border-radius: 0; --bs-card-inner-border-radius: 0;">
            <figure class="card-img-top m-0 overflow-hidden bsb-overlay-hover">
              <a href="">
              <?php if($inventory->featured_image): ?>
                                <a href="<?php echo e(route('frontend.inventories.show', $inventory->id)); ?>"  style="display: inline-block">
                                    <img src="<?php echo e($inventory->featured_image->getUrl()); ?>" loading="lazy" width="100%" class="img-fluid">
                                </a>
                            <?php endif; ?>              </a>

            </figure>
            <div class="card-body border-0 bg-white p-4">
              <div class="entry-header mb-3">
                <h5 class="card-title entry-title h4 mb-0">
                  <a class="link-dark link-opacity-100 link-opacity-75-hover text-decoration-none" href="<?php echo e(route('frontend.inventories.show', $inventory->id)); ?>"><?php echo e($inventory->title); ?></a>
                </h5>
               <p class="text-muted"> <?php if($inventory->year): ?><strong>Year:</strong> <?php echo e($inventory->year); ?> <?php endif; ?>
               <?php if($inventory->make): ?> <strong>Make:</strong> <?php echo e($inventory->make); ?> <?php endif; ?>
               <?php if($inventory->vehicle_model): ?> <strong>Model:</strong> <?php echo e($inventory->vehicle_model); ?> <?php endif; ?></p>

              </div>
            </div>
          </div>
        </article>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>
        </article>
      </div>
    </div>
  </div>


  <?php if($page == "home" || $page == ""): ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12 text-center">
            <a class="btn btn-warning" href="<?php echo e(route('frontend.inventories.index')); ?>">
               <strong> View More Inventory </strong>
            </a>
        </div>
    </div>
</div>
<?php elseif($page == "categories"): ?>
<div class="container">
        <div class="col-lg-12 text-center">
<div class="d-flex justify-content-center">
    <?php echo e($inventories->links('pagination::bootstrap-4')); ?>

</div>
</div>
</div>
<?php elseif($page == "inventories"): ?>
<div class="container">
        <div class="col-lg-12 text-center">
<div class="d-flex justify-content-center">
    <?php echo e($inventories->links('pagination::bootstrap-4')); ?>

</div>
</div>
</div>
<?php endif; ?>

</section>


<?php else: ?>
<h3 class="text-center py-5">No inventory available in this section</h3>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Brandywine_Project\resources\views/partials/featuredlistings.blade.php ENDPATH**/ ?>