@php
    $menus = \App\Models\Menu::where('published', 1)->get();
@endphp
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            @foreach($menus as $menu)
                @if($menu->parent_id == 0)
                    @php
                        $hasSubmenu = $menus->where('parent_id', $menu->id)->count() > 0;
                    @endphp
                    <li class="nav-item @if($hasSubmenu) dropdown @endif">
                        <a class="nav-link @if($hasSubmenu) dropdown-toggle @endif" href="{{ $menu->url ? $menu->url : route('frontend.content-pages.show', $menu->page->id) }}" @if($hasSubmenu) id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" @endif>
                            {{ $menu->name }}
                        </a>
                        @if($hasSubmenu)
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            @foreach($menus as $submenu)
                                @if($submenu->parent_id == $menu->id)
                                    <a class="dropdown-item" href="{{ $submenu->url ? $submenu->url : route('frontend.content-pages.show', $submenu->page->id) }}">{{ $submenu->name }}</a>
                                @endif
                            @endforeach
                        </div>
                        @endif
                    </li>
                @endif
            @endforeach 
          
        </ul>
    </div>
