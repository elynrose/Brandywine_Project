@extends('layouts.frontend')
@section('content')
<div class="container">
  
@include('partials.featuredlistings')
</div>
@endsection
