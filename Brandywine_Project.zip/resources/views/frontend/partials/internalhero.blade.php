  <!-- Service 10 - Bootstrap Brain Component -->
  <section class="inner">
            <div class="container hero mb-5">
                <div class="row justify-content-md-center" style="position:relative;">
                    <div class="col-12 col-md-10 col-lg-8 col-xl-7 col-xxl-6 inner-center">
                        <h1 class="mt-5 display-5 text-center"> {{ $category->name }}</h1>
                        <h5 class="text-center">Browse Our Selection of {{ $category->name }}</h5>
                    </div>
                </div>
            </div>
</section>
